﻿using CRM_API.DTOs;
using CRM_API.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using SharedLibrary.Hubs;

namespace CRM_API.Controllers
{
    [Route("api/webhook/whatsapp")]
    [ApiController]
    public class WhatsAppWebhookController : ControllerBase
    {
        private readonly IChatService _chatService;
        private readonly IHubContext<ChatHub> _hubContext;

        public WhatsAppWebhookController(IChatService chatService, IHubContext<ChatHub> hubContext)
        {
            _chatService = chatService;
            _hubContext = hubContext;
        }

        [HttpGet]
        public IActionResult Verify()
        {
            var query = Request.Query;

            string mode = query["hub.mode"];
            string challenge = query["hub.challenge"];
            string verifyToken = query["hub.verify_token"];

            if (mode == "subscribe" && verifyToken == "123456")
            {
                return Ok(challenge);
            }

            return Forbid();
        }

        [HttpPost]
        public async Task<IActionResult> Receive([FromBody] WhatsAppWebhookPayload payload)
        {
            var msg = payload.Entry?.FirstOrDefault()?.Changes?.FirstOrDefault()?.Value?.Messages?.FirstOrDefault();
            var contactPhone = msg?.From;
            var businessPhone = payload.Entry?.FirstOrDefault()?.Changes?.FirstOrDefault()?.Value?.Metadata?.Display_Phone_Number;

            if (msg == null || string.IsNullOrEmpty(contactPhone)) return Ok();

            var dto = new ReceiveMessageDTO
            {
                From = contactPhone,
                To = businessPhone,
                Timestamp = DateTimeOffset.FromUnixTimeSeconds(long.Parse(msg.Timestamp)).LocalDateTime
            };

            // ✅ Handle all supported types BEFORE calling the service
            if (msg.Type == "image" && msg.Image != null)
            {
                dto.Message = await _chatService.DownloadMediaAndSaveAsync(msg.Image.Id, "image");
                dto.MessageType = "image";
            }
            else if (msg.Type == "video" && msg.Video != null)
            {
                dto.Message = await _chatService.DownloadMediaAndSaveAsync(msg.Video.Id, "video");
                dto.MessageType = "video";
            }
            else if (msg.Type == "audio" && msg.Audio != null)
            {
                dto.Message = await _chatService.DownloadMediaAndSaveAsync(msg.Audio.Id, "audio");
                dto.MessageType = "audio";
            }
            else if (msg.Type == "document" && msg.Document != null)
            {
                dto.Message = await _chatService.DownloadMediaAndSaveAsync(msg.Document.Id, "document");
                dto.MessageType = "document";
            }
            else if (msg.Type == "text" && msg.Text != null)
            {
                dto.Message = msg.Text.Body;
                dto.MessageType = "text";
            }

            // 🔁 Send to service
            await _chatService.ReceiveWebhookAsync(dto);

            return Ok();
        }

    }
}
